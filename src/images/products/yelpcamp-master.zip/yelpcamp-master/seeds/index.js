const mongoose = require('mongoose');
const cities = require('./cities');
const Campground = require('../models/campground');
const { places, descriptors } = require('./seedHelpers');

mongoose.connect('mongodb://127.0.0.1:27017/yelp-camp', {useNewURLParser: true, useUnifiedTopology: true});

const db = mongoose.connection;
db.on("error",  console.error.bind(console, "connection error"));
db.once("open", () => {
    console.log("Database Connected");
});

const sample = array => array[Math.floor(Math.random() * array.length)];

const seedDB = async () => {
    await Campground.deleteMany({});
    for(let i = 0; i < 50; i++){
        const random1000 = Math.floor(Math.random() * 1000);
        const camp = new Campground({
            author: "63cc5daa1a4f530ccdb1e4f8",
            location: `${cities[random1000].city}, ${cities[random1000].state}`,
            title: `${sample(descriptors)} ${sample(places)}`,
            images: [
                {
                url: 'https://res.cloudinary.com/dtuwivkx6/image/upload/v1675227590/YelpCamp/0x0_ilt1or.jpg',
                filename: 'YelpCamp/0x0_ilt1or.jpg',
              },
              {
                url: 'https://res.cloudinary.com/dtuwivkx6/image/upload/v1675227599/YelpCamp/giannis-antetokounmpo-fttr_payq94.jpg',
                filename: 'YelpCamp/giannis-antetokounmpo-fttr_payq94.jpg',
              },
              {
                url: 'https://res.cloudinary.com/dtuwivkx6/image/upload/v1675227599/YelpCamp/michael-jordan-looks_jje1bf.jpg',
                filename: 'YelpCamp/michael-jordan-looks_jje1bf.jpg',
              }
            ],
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla laoreet velit et quam mollis, rutrum faucibus arcu gravida. Vivamus consequat ornare lectus, id hendrerit magna sagittis a. Ut vitae dui nec lacus dictum dapibus quis vel massa. Vivamus cursus enim at nulla accumsan, at dapibus magna fringilla. Phasellus nec fermentum lacus.",
            price: Math.floor(Math.random() * 20) + 10,
            geometry: {
              type: "Point",
              coordinates: [
                cities[random1000].longitude,
                cities[random1000].latitude,
            ],
          },
        })
        await camp.save();
    }
}

seedDB().then(() => {
    mongoose.connection.close();
})